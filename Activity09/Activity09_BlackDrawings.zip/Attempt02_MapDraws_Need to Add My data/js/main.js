//begin script when window loads
window.onload = setMap();

//Example 1.3 line 4...set up choropleth map
function setMap() {
    //use Promise.all to parallelize asynchronous data loading

    var promises = [
        d3.csv("data2/netorn_2000_PropLoss.csv"),
        d3.json("data2/Neb.topojson"),
        d3.json("data2/NE_Counties.topojson"),
    ];
    Promise.all(promises).then(callback);
}

function callback(data) {
    var csvData = data[0],
        nebraska = data[1],
        counties = data[2];

    //translate europe TopoJSON
    var neb_outline = topojson.feature(nebraska, nebraska.objects.Neb),
        neco = topojson.feature(counties, counties.objects.NE_Counties);

    //examine the results
    console.log(neb_outline)
    console.log(neco);
}

