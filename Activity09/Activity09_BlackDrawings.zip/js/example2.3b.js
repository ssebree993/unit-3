//begin script when window loads
window.onload = setMap();

//Example 1.3 line 4...set up choropleth map
function setMap() {
    //map frame dimensions
    var width = 960,
        height = 460;

    //create new svg container for the map
    var map = d3
        .select("body")
        .append("svg")
        .attr("class", "map")
        .attr("width", width)
        .attr("height", height);

    //create Albers equal area conic projection centered on France
    var projection = d3.geoAlbers()
        .center([-18.18, 51.78])
        .rotate([84.64, 11.82, 0])    
        .parallels([30.18, 27.00])    
        .scale(4000)    
        .translate([width / 2, height / 2]);

    var path = d3.geoPath().projection(projection);

    //use Promise.all to parallelize asynchronous data loading
    var promises = [
        d3.csv("data2/netorn_2000_PropLoss.csv"),
        d3.json("data2/NE_Counties.topojson"),
        d3.json("data2/Neb.topojson"),
    ];
    Promise.all(promises).then(callback);

    function callback(data) {
        var csvData = data[0],
            county = data[1],
            state = data[2];

        //translate europe TopoJSON
        var countys = topojson.feature(county, county.objects.NE_Counties),
            states = topojson.feature(state, state.objects.Neb).features;

        //add counties to map
        var neco = map
            .append("path")
            .datum(countys)
            .attr("class", "neco")
            .attr("d", path);

        //add Nebraska State to map
        var neco = map
            .selectAll(".countys")
            .data(states)
            .enter()
            .append("path")
            .attr("class", function (d) {
                return "states " + d.properties.FIPS;
            })
            .attr("d", path);
    }
}
